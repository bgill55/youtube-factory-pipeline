"""Video generation providers."""
